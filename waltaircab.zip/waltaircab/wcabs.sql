-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2017 at 03:24 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wcabs`
--

-- --------------------------------------------------------

--
-- Table structure for table `wc_admin`
--

CREATE TABLE `wc_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wc_admin`
--

INSERT INTO `wc_admin` (`id`, `name`, `mobile`, `password`) VALUES
(1, 'admin', '7995594444', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `wc_tripdetails`
--

CREATE TABLE `wc_tripdetails` (
  `id` int(11) NOT NULL,
  `sheetNo` varchar(20) NOT NULL,
  `tripDate` date NOT NULL,
  `openingTime` varchar(150) NOT NULL,
  `openingKm` varchar(150) NOT NULL,
  `customerName` varchar(150) NOT NULL,
  `customerAddress` varchar(250) NOT NULL,
  `customerCell` varchar(15) NOT NULL,
  `reportingPlace` varchar(250) NOT NULL,
  `customerAadharNo` varchar(20) NOT NULL,
  `driverName` varchar(250) NOT NULL,
  `vehicleNo` varchar(150) NOT NULL,
  `advance` varchar(100) NOT NULL,
  `total_amt` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wc_tripdetails`
--

INSERT INTO `wc_tripdetails` (`id`, `sheetNo`, `tripDate`, `openingTime`, `openingKm`, `customerName`, `customerAddress`, `customerCell`, `reportingPlace`, `customerAadharNo`, `driverName`, `vehicleNo`, `advance`, `total_amt`, `created`) VALUES
(1, '1', '2017-07-18', '09:09', '776', 'Curly', 'AMP', '90007671', 'VSKP', '80010035629', 'Srinu', 'AP31TU9098', '1200', '7000', '2017-07-18 14:49:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wc_admin`
--
ALTER TABLE `wc_admin`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wc_tripdetails`
--
ALTER TABLE `wc_tripdetails`
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `sheetNo` (`sheetNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wc_admin`
--
ALTER TABLE `wc_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wc_tripdetails`
--
ALTER TABLE `wc_tripdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
