
var numericExpression = /^[0-9]+$/;

function reset () 
{
	$("#toggleCSS").attr("href", "../css/alertify.default.css");
		alertify.set({
			labels : {
				ok     : "OK",
				cancel : "Cancel"
				},
				delay : 2000,
				buttonReverse : false,
				buttonFocus   : "ok"
			});
}




 
function validatePost()
{
    var numericExpression = /^[0-9]+$/;
   
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;

    var sheetNo = document.forms["tripDetails"]["sheetNo"].value;
	var sheetNof = document.forms["tripDetails"]["sheetNo"];
	
    var tripDate = document.forms["tripDetails"]["tripDate"].value;
    var tripDatef = document.forms["tripDetails"]["tripDate"];	
	
	
	
	
	var opening_time = document.forms["tripDetails"]["opening_time"].value;
	var opening_timef = document.forms["tripDetails"]["opening_time"];
	
	var opening_kms = document.forms["tripDetails"]["opening_kms"].value;
	var opening_kmsf = document.forms["tripDetails"]["opening_kms"];
	
	
	var Customer_Name = document.forms["tripDetails"]["Customer_Name"].value;
	var Customer_Namef = document.forms["tripDetails"]["Customer_Name"];
	
	
	
	var Customer_Address = document.forms["tripDetails"]["Customer_Address"].value;
	var Customer_Addressf = document.forms["tripDetails"]["Customer_Address"];
	
	var Customer_Cell_No = document.forms["tripDetails"]["Customer_Cell_No"].value;
	var Customer_Cell_Nof = document.forms["tripDetails"]["Customer_Cell_No"];
	
	var Report_place = document.forms["tripDetails"]["Report_place"].value;
	var Report_placef = document.forms["tripDetails"]["Report_place"];
	
	 //var x=document.tripDetails;
       //txt=x.mobile.value.length;
	
	var aadhar_no = document.forms["tripDetails"]["aadhar_no"].value;
	var aadhar_nof = document.forms["tripDetails"]["aadhar_no"];
	
	var driverName = document.forms["tripDetails"]["driverName"].value;
	var driverNamef = document.forms["tripDetails"]["driverName"];
	
	var vehicleNo = document.forms["tripDetails"]["vehicleNo"].value;
	var vehicleNof = document.forms["tripDetails"]["vehicleNo"];
	
	
	var advance = document.forms["tripDetails"]["advance"].value;
	var advancef = document.forms["tripDetails"]["advance"];
	
	
	var total_amt = document.forms["tripDetails"]["total_amt"].value;
	var total_amtf = document.forms["tripDetails"]["total_amt"];
	
	
	if (sheetNo == null || sheetNo == "") 
	{
		
		    reset();
			sheetNof.focus(alertify.error("Enter The Sheet No"));
	        return false;
			
    }
	
	if(!sheetNo.match(numericExpression))  
     {  
         reset();
		alertify.error("Sheet No Must Be Numaric");
		 sheetNof.focus();
       return false;  
     }
	
	
	
	
	if (tripDate == null || tripDate == "") 
	{
        reset();
		alertify.error("Enter The Trip Date");
		tripDatef.focus();
		
		 
        return false;
    }
	
	
	
	
	if (opening_time == null || opening_time == "") 
	{
        reset();
		alertify.error("Enter The Opening Time");
		opening_timef.focus();
		
		 
        return false;
    }
	
	
	if (opening_kms == null || opening_kms == "") 
	{
        reset();
		alertify.error("Enter The Opening kms");
		opening_kmsf.focus();
		
		 
        return false;
    }
	
	
	if (Customer_Name == null || Customer_Name == "") 
	{
        reset();
		alertify.error("Enter The Customer Name");
		Customer_Namef.focus();
		
		 
        return false;
    }
	
	if (Customer_Address == null || Customer_Address == "") 
	{
        reset();
		alertify.error("Enter The CustomerAddress");
		Customer_Addressf.focus();
		
		 
        return false;
    }
	
	
	if (Customer_Cell_No == null || Customer_Cell_No == "") 
	{
        reset();
		alertify.error("Enter The Customer Cell No");
		Customer_Cell_Nof.focus();
		
		 
        return false;
    }
	
	
	if (Report_place == null || Report_place == "") 
	{
        reset();
		alertify.error("Enter The Report Place");
		Report_placef.focus();
		
		 
        return false;
		
    }
	
	
	if (aadhar_no == null || aadhar_no == "") 
	{
        reset();
		alertify.error("Enter The Aadha No");
		aadhar_nof.focus();
		
		 
        return false;
    }
	
	
	if (driverName == null || driverName == "") 
	{
        reset();
		alertify.error("Enter The Driver Name");
		driverNamef.focus();
		
		 
        return false;
    }
	
	if (vehicleNo == null || vehicleNo == "") 
	{
        reset();
		alertify.error("Enter The Vehicle No");
		vehicleNof.focus();
		
		 
        return false;
    }
	
	if (advance == null || advance == "") 
	{
        reset();
		alertify.error("Enter The Advance Amt");
		advancef.focus();
		
		 
        return false;
    }
	
	if (total_amt == null || total_amt == "") 
	{
        reset();
		alertify.error("Enter The Total Amt ");
		total_amtf.focus();
		
		 
        return false;
    }
	
		
		
		
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 /*  log in start */
function validateUserLogIn()
{ 
    var numericExpression = /^[0-9]+$/;
   
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
   
	
    var mobile = document.forms["loginForm"]["mobile"].value;	
    var mobilef = document.forms["loginForm"]["mobile"];

    var pass = document.forms["loginForm"]["password"].value;	
    var passf = document.forms["loginForm"]["password"];
	
	
	
	
	
	if (mobile == null || mobile == "") 
	{
        reset();
		alertify.error("Enter  The Mobile No");
		mobilef.focus();
        return false;
    }
	 
	if(!mobile.match(numericExpression))  
    {  
 
         reset();
		 alertify.error("Mobile Number Must Be Numeric ");
		 mobilef.focus();
        return false;
    }
	
	
	if (pass == null || pass== "") {
			reset();
			alertify.error("Enter The Password!");
			passf.focus();
			return false;
    }


}
/*  log in close */

	


/*  create user form start */


function validateUserRegistration()
{ 
    var numericExpression = /^[0-9]+$/;
    var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
	
   
	
    var FirstName = document.forms["registration"]["FirstName"].value;	
    var FirstNamef = document.forms["registration"]["FirstName"];	
	var LastName = document.forms["registration"]["LastName"].value;	
    var LastNamef = document.forms["registration"]["LastName"];	
	//var UserName = document.forms["registration"]["UserName"].value;	
    //var UserNamef = document.forms["registration"]["UserName"];	

	
	var Email = document.forms["registration"]["Email"].value;
    var Emailf = document.forms["registration"]["Email"];
	

    
	
    var pass = document.forms["registration"]["Password"].value;	
    var passf = document.forms["registration"]["Password"];	
   
    var  pa=document.forms["registration"]["Password"].value.length;
	
	var con = document.forms["registration"]["ConfirmPassword"].value;	
    var conf = document.forms["registration"]["ConfirmPassword"];	
	
    var CountryId = document.forms["registration"]["CountryId"].value;
    var CountryIdf = document.forms["registration"]["CountryId"];
	
	var State = document.forms["registration"]["State"].value;	
    var Statef = document.forms["registration"]["State"];
	
	var State2 = document.forms["registration"]["State2"].value;	
    var State2f = document.forms["registration"]["State2"];	
	
	var City = document.forms["registration"]["City"].value;	
    var Cityf = document.forms["registration"]["City"];	
	
	var Address = document.forms["registration"]["Address"].value;	
    var Addressf = document.forms["registration"]["Address"];	
	
	

    var Phone = document.forms["registration"]["mobile"].value;	
    var Phonef = document.forms["registration"]["mobile"];	

    var x=document.registration;
       txt=x.mobile.value.length;	
	   
	var terms = document.forms["registration"]["terms"].value;
	var termsf = document.forms["registration"]["terms"];   
	

	
	
	
	
	if (FirstName == null || FirstName== "") 
	{
			reset();
			alertify.error("Enter The User First Name!");
			FirstNamef.focus();
			return false;
    }
	
	if (LastName == null || LastName== "")
	{
			reset();
			alertify.error("Enter The User Last Name!");
			LastNamef.focus();
			return false;
    }
	
	
	
	   
	if (Email == null || Email == "") 
	{
        reset();
		alertify.error("Enter  The E-mail Id");
		Emailf.focus();
        return false;
    }
	 
	 if(!Email.match(emailExp))  
     {  
 
         reset();
		 alertify.error("Not  A  Valid E-mail Format \nEX:   example@domail.com");
		 Emailf.focus();
        return false;
     }
	 
	 
	 if (Phone == null || Phone== "") {
			reset();
			alertify.error("Enter The Mobile Number");
			Phonef.focus();
			return false;
    }
 	
	if(!Phone.match(numericExpression))  
     {  
         reset();
		alertify.error("Mobile Number Must Be Numaric");
		 Phonef.focus();
       return false;  
     }
	 
	 
	 if (txt!=10)
	   {
           reset();
		alertify.error("Mobile Number	must be 10 digits!");
		Phonef.focus();
            return false
       }
	
	if (pass == null ||pass== "") {
			reset();
			alertify.error("Enter The Password!");
			passf.focus();
			return false;
    }
	
	
	
	 if (pa<5)
	   {
           reset();
		alertify.error("Password Must Be Above 5 Characters!");
		passf.focus();
            return false
       }
	
	

    if (con == null || con== "") 
	{
			reset();
			alertify.error("Enter The Conform Password!");
			conf.focus();
			return false;
    }

    if (pass !== con) 
	{
			reset();
			CountryIdf.focus(alertify.error("Select The Country"));
			conf.focus();
			return false;
    }

	
  if (CountryId == null || CountryId == "") 
	 {
		  reset();
		alertify.error("Select The Country");
		CountryIdf.focus();
        return false;
    } 
	
	
	if(CountryId =="INDIA")
	{
		
		if (State == null || State== "") {
			reset();
			alertify.error("Enter The State Name");
			Statef.focus();
			return false;
       }
		
	}
	
	else {
		
		if (State2 == null || State2== "") {
			reset();
			alertify.error("Enter The State Name");
			State2f.focus();
			return false;
       }
	}
	
	
	/*
	
	
	*/
	
	if (City == null || City == "") 
	{
        reset();
		alertify.error("Enter The City");
		Cityf.focus();
		
		 
        return false;
    }
	
	
	
	if (Address == null || Address == "") 
	{
        reset();
		alertify.error("Enter The Address");
		Addressf.focus();
		
		 
        return false;
    }
	
	
	
	if(termsf.checked== false)
	{
		
		    reset();
			termsf.focus(alertify.error("Accept The Terms & Conditions"));
	        return false;
			
    } 
	
	/*
	
	
	
	
	
	
	if (Street1 == null ||  Street1== "") {
			reset();
			alertify.error("Enter The Street 1");
			Street1f.focus();
			return false;
    }
	
	if (Zip == null ||  Zip== "") {
			reset();
			alertify.error("Enter The Zip Code");
			Zipf.focus();
			return false;
    }
	
	if(!Zip.match(numericExpression))  
     {  
         reset();
		alertify.error("Zip Code Must Be Numaric");
		 Zipf.focus();
       return false;  
     }
	
	
	
	
	 */
}
/*  create user form close */




/*File Upload start */

function ValidateExtension() 
{
        var allowedFiles = [".jpg", ".jpeg", ".bmp", ".gif", ".png"];
        var fileUpload = document.getElementById("fileUpload");
		var lblError = document.getElementById("lblError");
		
		if(fileUpload.size===0)
		{
			lblError.innerHTML = "Select The File ";
		}
		
		else
		{
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + allowedFiles.join('|') + ")$");
        if (!regex.test(fileUpload.value.toLowerCase())) 
		{
            lblError.innerHTML = "Upload files having extensions: <b>" + allowedFiles.join(', ') + "</b> only.";
            return false;
        }
		}
        lblError.innerHTML = "";
        return true;
 }

/*File Upload close */
