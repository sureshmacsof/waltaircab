 <?php 
 
    if(isset($_POST["id"]))
    {
        $id = $_POST["id"];
       
    }  
	
	include 'connect.php';
	
     $query = mysqli_query($con,"SELECT `postId`, `memberEmail`, `countryName`, `province`, `cityName`, `categoryID`, `categoryName`, `subCatId`, `subcatName`, `postingTitle`, `description`, `contactName`, `address`, `email`, `mobile`, `postingDate`, `status`, `price` FROM `postdetails` WHERE	`postId`='$id'");
	 
	 
	 
		 
	if($query)
	{

	 if(mysqli_num_rows($query) > 0)
	 {
		$row=mysqli_fetch_assoc($query);
					
									
					
					$countryName=$row["countryName"];
					$province=$row["province"];
					$cityName=$row["cityName"];
					$categoryID=$row["categoryID"];
					$categoryName=$row["categoryName"];
					$subCatId=$row["subCatId"];
					$subcatName=$row["subcatName"];
					$postingTitle=$row["postingTitle"];
					$description=$row["description"];
					$address=$row["address"];
					$email=$row["email"];
					$mobile=$row["mobile"];
					$postingDate=$row["postingDate"];
					$price=$row["price"];
					
	$query2 ="SELECT `categoryid`, `categoryname`, `image`, `status` FROM `category`";
																   
			 $result33 = mysqli_query($con,$query2);
																	   
				 if($result33)
					{
																		   
						while($row33=mysqli_fetch_assoc($result33)) 
							{
								$resultset33[] = $row33;
							}		
								if(!empty($resultset33))
									$results33 =  $resultset33;


					}			 
			 				
					
  echo'<div class="row">
        <div class="col-md-12">
         <div class="panel">
          <div class="panel-body">
		   <form class="reg-page">
		   
		     <div class="row" style="margin-bottom: 30px;">
				<div class="col-sm-5">
					<label>Edit  The  Tilte About The Post <span class="color-red">*</span></label>
											
					<textarea name="titlee"    rows="1" class="form-control margin-bottom-20"  id="titlee" >'.$postingTitle.'</textarea>
					
					
				</div>
				<div class="col-sm-offset-2 col-sm-5">
								<label>Edit  The  Price <span class="color-red">*</span></label>
											
								<input  name="pricee"  placeholder="Enter  The  Price" type="text" style="text-align:center;" class="form-control margin-bottom-20" value="'.$price.'"  id="pricee">
								
								<input type="hidden" id="postIde" value="'.$id.'">
								
								
				</div>
			 </div>
			 
			 <div class="row" style="margin-bottom: 30px;">
						  <div class="col-sm-5">
							<label>Edit  The  Category <span class="color-red">*</span></label>
											
								<select name="categorye" class="form-control" id="categorye"  onChange="getSub_Categorye(this.value);">';
										
									foreach($results33 as $Category3) 
									{
										
										echo'<option value="'.$categoryID.'" selected>'.$categoryName.'</option>
										
										<option value="'.$Category3["categoryid"].'" > '.$Category3["categoryname"].'
										</option>';
												 
									}
												
								echo'</select>
								
						  </div>
						 <div class="col-sm-offset-2 col-sm-5">
							<label>Edit  The  Sub-Category <span class="color-red">*</span></label>
											   
							<select name="Sub_Categorye"  class="form-control" id="subcategorye">
								<option value="'.$subCatId.'" selected>'.$subcatName.'</option>
							</select>
							
							
						</div>
                </div>
				
				
				 <div class="row" style="margin-bottom: 30px;">
						<div class="col-sm-12">
							<label>Edit  The  Description <span class="color-red">*</span></label>
											
							<textarea name="detaile" id="detaile" class="form-control margin-bottom-20" rows="2" data-parsley-group="wizard-step-1" required>'.$description.'</textarea>
											
					    </div>
				</div>
				
				<div class="row" style="margin-bottom: 30px;">
						<div class="col-sm-5">
							<label>Edit The State <span class="color-red">*</span></label>
											
							<select class="form-control margin-bottom-20"  name="statee" id="statee">
										<option value="'.$province.'">'.$province.' </option>
									    <option value="Andhra Pradesh">Andhra Pradesh </option>
										<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
										<option value="Arunachal Pradesh">Arunachal Pradesh</option>
										<option value="Assam">Assam</option>
										<option value="Bihar">Bihar</option>
										<option value="Chandigarh">Chandigarh</option>
										<option value="Chhattisgarh">Chhattisgarh</option>
										<option value="Delhi">Delhi</option>
										<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
										<option value="Daman and Diu">Daman and Diu</option>
										<option value="Goa">Goa</option>
										<option value="Gujarat">Gujarat</option>
										<option value="Haryana">Haryana</option>
										<option value="Himachal Pradesh">Himachal Pradesh</option>
										<option value="Jammu and Kashmir">Jammu and Kashmir</option>
										<option  value="Jharkhand">Jharkhand</option>
										<option value="Karnataka">Karnataka</option>
										<option value="Kerala">Kerala</option>
										<option value="Lakshadweep">Lakshadweep</option>
										<option value="Madhya Pradesh">Madhya Pradesh</option>
										<option value="Maharashtra">Maharashtra</option>
										<option value="Manipur">Manipur</option>
										<option value="Meghalaya">Meghalaya</option>
										<option value="Mizoram">Mizoram</option>
										<option value="Nagaland">Nagaland</option>
										<option value="Odisha">Odisha</option>
										<option value="Pondicherry">Pondicherry</option>
										<option value="Punjab">Punjab</option>
										<option value="Rajasthan">Rajasthan</option>
										<option value="Sikkim">Sikkim</option>
										<option value="Tamil Nadu">Tamil Nadu</option>
										<option value="Tripura">Tripura</option>
										<option value="Uttar Pradesh">Uttar Pradesh</option>
										<option value="Uttarakhand">Uttarakhand</option>
										<option value="West Bengal">West Bengal</option>
																			
						     </select>
						</div>
										
										
						<div class="col-sm-offset-2 col-sm-5">
							<label>Edit  The  City <span class="color-red">*</span></label>
											
											
							<input class="form-control" name="citye"  type="text" style="text-align:center;" value="'.$cityName.'" id="citye">
														
														
						</div>
				</div>
				
				<div class="row" style="margin-bottom: 30px;">
						<div class="col-sm-5">
							<label>Edit  The  Mobile Number <span class="color-red">*</span></label>
											
							<input class="form-control" name="mobilee"  type="text" style="text-align:center;" value="'.$mobile.'"  id="mobilee">
						</div>
						<div class="col-sm-offset-2 col-sm-5">
							<label>Edit  The  Email <span class="color-red">*</span></label>
											
											
							<input class="form-control" name="emaile"   value="'.$email.'" type="email" style="text-align:center;" id="emaile">
														
														
						</div>
				</div>
				
				<div class="row">
											
						<div class="col-sm-offset-1 col-sm-6 text-right">
											
							
							
							<input type="submit" value="Update" id="submitpost" name="submit" class="btn btn-primary btn-lg">
							
						</div>
				</div>
				
			
			
	      </form>
         </div>
       </div>      
      </div>
    </div>';	
	}
				
  }	

     		
   
	
  ?>