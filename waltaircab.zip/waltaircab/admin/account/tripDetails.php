<?php 

@session_start();



if(isset($_SESSION['UserName']) && isset($_SESSION['mobile']) )
			{
				 $UserName = $_SESSION['UserName'];
				 $mobile= $_SESSION['mobile'];
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['mobile'] =$mobile;
					
			}
				
		else {  
				 header('location: ../index.php');
				  
			 }

   
	
 if (isset($_POST['submit'])) 
 {    
	include('connect.php');
    if (empty($_POST['sheetNo']) || empty($_POST['tripDate']) || empty($_POST['opening_time'])  || empty($_POST['opening_kms']) || empty($_POST['Customer_Name']) || empty($_POST['Customer_Address']) || empty($_POST['Customer_Cell_No']) || empty($_POST['Report_place']) || empty($_POST['aadhar_no']) || empty($_POST['driverName']) || empty($_POST['vehicleNo'])|| empty($_POST['advance'])|| empty($_POST['total_amt']) )  
    {
        $error = "Details are invalid";
		echo"$error";
    }
	
    else
    { 
         
		   $sheetNo=$_POST['sheetNo'];
		   $tripDate=$_POST['tripDate'];
		   $opening_time=$_POST['opening_time'];
		   $opening_kms=$_POST['opening_kms'];
		   $Customer_Name=$_POST['Customer_Name'];
		   $Customer_Address=$_POST['Customer_Address'];
		   $Customer_Cell_No=$_POST['Customer_Cell_No'];		   
		   $Report_place=$_POST['Report_place'];
		   $aadhar_no=$_POST['aadhar_no'];		  
		   $driverName=$_POST['driverName'];		  
		   $vehicleNo=$_POST['vehicleNo'];		  
		   $advance=$_POST['advance'];		  
		   $total_amt=$_POST['total_amt'];		  
		  
		   
		   date_default_timezone_set('Asia/Calcutta');	   

		   $created = date('Y-m-d H:i:s'); 
		   
		   $id= round(microtime(true));
		   
		  
			   
			   
	$sql= "INSERT INTO `wc_tripdetails`(`id`, `sheetNo`, `tripDate`, `openingTime`, `openingKm`, `customerName`, `customerAddress`, `customerCell`, `reportingPlace`, `customerAadharNo`, `driverName`, `vehicleNo`, `advance`, `total_amt`, `created`)  VALUES (null,'".$sheetNo."','".$tripDate."','".$opening_time."','".$opening_kms."','". $Customer_Name."','".$Customer_Address."','".$Customer_Cell_No."','".$Report_place."','".$aadhar_no."','".$driverName."','".$vehicleNo."', '".$advance."','".$total_amt."','".$created."')";
			   
			

	                 mysqli_query($con,$sql);
			   
			  echo"<script type='text/javascript'>
                alert('Successfully Store The Trip Details ');
                  </script> ";
				
              echo "<script>window.location.href='index'</script>";
              exit; 
					
			
			
		   
		   
	}	   
		   
	 
	  
		 
		 
				   
			
	 mysqli_close($con);	
			
  }   //else
  

?>