<?php

session_start(); 

// if the sign up form was submitted
if($_POST)
{
 
    
 
    if( !empty($_POST['mobile'])|| !empty($_POST['Password'])|| !empty($_POST['ConfirmPassword'])|| !empty($_POST['Email'])|| !empty($_POST['FirstName'])|| !empty($_POST['LastName']) || !empty($_POST['CountryId']) || !empty($_POST['Address']) || !empty($_POST['City']))  
    {
 
        include 'connect.php';
		
		$Email=$_POST["Email"];
 
        // check first if record exists
        
		$query = mysqli_query($con,"SELECT `id` FROM `member` WHERE `email` ='$Email' and `verified` = '1'");
		
		
		
		$rowcount=mysqli_num_rows($query);
		 
		 if($rowcount > 0)
				{
				  
					 echo "<div>Your email is already activated.</div>";
				}
		
 
        else{
 
            
			$query = mysqli_query($con,"SELECT `id` FROM `member` WHERE `email` ='$Email' and `verified` = '0'");
			
			
			
		
		   $rowcount=mysqli_num_rows($query);
		 
		    if($rowcount > 0)
				{
				  
					echo "<div>Your email is already in the system but not yet verified.</div>";
				}
		
			
 
            else
			
			{
				     
                      $FirstName=$_POST["FirstName"];
			          $LastName=$_POST["LastName"];
					 		  
					  $Email=$_POST["Email"];
					  $Phone=$_POST["mobile"];
					  $CountryId=$_POST["CountryId"];
					  
					  $City=$_POST["City"];
					  $Address=$_POST["Address"];
					  
					  
					 
					  
                      date_default_timezone_set('Asia/Calcutta');         
					  $created = date('Y-m-d H:i:s');   
					 
				      //$password1=md5($_POST["Password"]);
			          //$password2=md5($_POST["ConfirmPassword"]);

					  $password1=$_POST["Password"];
			          $password2=$_POST["ConfirmPassword"];	
					  
					   //$State=$_POST["State"];
					 
                     					 
					  if(!empty($_POST['State']))
					  {
						  $State=$_POST["State"];
					  }
					  
					  else{
						  
						  $State=$_POST["State2"];
					  }
				     
				
			   if ($password1==$password2)
               {	
				
 
                // now, compose the content of the verification email, it will be sent to the email provided during sign up
                // generate verification code, acts as the "key"
                $verificationCode = md5(uniqid('yourrandomstringyouwanttoaddhere', true));
 
                // send the email verification
            
               
                $htmlStr = "";
                $htmlStr .= "Dear " .  $FirstName . ",<br /><br />";
 
                $htmlStr .= "Thank you for submitting your registration details to http://www.shineclassifieds.com To complete your registration and to continue with your request, please click this link " ." <a href='http://srikanthministries.org/ShineClisified/account/activate.php?code=".$verificationCode."'  target='_blank' style='padding:1em; font-weight:bold; background-color:blue; //color:#fff;'>VERIFY EMAIL</a> to activate your account.<br /><br/>
				<br/>If you received this message but did not attempt to register, it means that someone may have entered your email address when registering at http://www.shineclassifieds.com probably by mistake. If this is the case, please disregard this email - no further action is required. We apologize for the inconvenience.";

 
                $htmlStr .= "<br><br>Best regards,<br />The shineclassifieds Team<br>";
                $htmlStr .= "support@shineclassifieds.com<br />";
 
 
                $name = "shineclassifieds";
                $email_sender = "support@shineclassifieds.com";
                $subject = "Verification Link | shineclassifieds | Subscription";
                $recipient_email = $Email;
 
                $headers  = "MIME-Version: 1.0\r\n";
                $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
                $headers .= "From: {$name} <{$email_sender}> \n";
 
                $body = $htmlStr;
 
                // send email using the mail function, you can also use php mailer library if you want
                if( mail($recipient_email, $subject, $body, $headers) )
		        { 
 
                   
					
					    
 
                    $sql= "INSERT INTO `member`(`id`, `FirstName`, `LastName`, `email`, `password`,  `verification_code`, `country`, `province`, `city`, `address`,  `mobileno`, `createdate`, `modified`)  VALUES (null,'".$FirstName."','".$LastName."','".$Email."','".$password1."','". $verificationCode."','".$CountryId."','".$State."','".$City."','".$Address."','".$Phone."','".$created."','".$created."')";

	                 mysqli_query($con,$sql);
	       
			       
			
			            $_SESSION['Email'] =$Email;
						$_SESSION['UserName'] ="$FirstName "."$LastName";
			  
			      echo "<script>window.location.href='finishRegistration.php'</script>";
                  exit; 
			
                }
				
				else
					
				 {
                     die("Sending failed.");
                  } 
				
			   }

                else 
                {
	            
	           echo"<script type='text/javascript'>
                alert('Password should not be matched');
                  </script> ";
				
              echo "<script>window.location.href='../signup'</script>";
              exit; 				
				
               }			   
					
            }///
 
 
        }
 
    } ///
	
	 else{
	    echo "Invalid details";
    }	
 
}
 

?>