<?php

  
  include 'connect.php';

//Fetching Values from URL  
$title=$_POST['title1'];
$price=$_POST['price1'];
$categoryId=$_POST['category1'];
$subcategoryId=$_POST['subcategory1'];
$detail=$_POST['detail1'];
$state=$_POST['state1'];
$city=$_POST['city1'];
$mobile=$_POST['mobile1'];
$email=$_POST['email1'];
$postId=$_POST['postId1'];
//$categoryNamee=$_POST['categoryNamee1'];
//$subcatNamee=$_POST['subcatNamee1'];

 date_default_timezone_set ("Asia/Calcutta"); 

 $created = date('Y-m-d H:i:s');   
 
 
 $query = mysqli_query($con,"SELECT  `categoryName`, `subcatName`  FROM `postdetails` WHERE	`postId`='$postId'");
	 
	 
	 
		 
	if($query)
	{

	 if(mysqli_num_rows($query) > 0)
	 {
		$row=mysqli_fetch_assoc($query);
		
		            $categoryName=$row["categoryName"];
					
					$subcatName=$row["subcatName"];
					
	 }
    }	 


//Insert query 

  // UPDATE `postdetails` SET `province`='$state',`cityName`='$city',`categoryID`='$categoryId',`categoryName`='$categoryName',`subCatId`='$subcategoryId',`subcatName`='$subcatName',`postingTitle`='$title',`description`='$detail',`email`='$email',`mobile`='$mobile',`price`='$price' WHERE `postId`='$postId'

   



  $query ="UPDATE `postdetails` SET `province`='$state',`cityName`='$city',`categoryID`='$categoryId',`categoryName`='$categoryName',`subCatId`='$subcategoryId',`subcatName`='$subcatName',`postingTitle`='$title',`description`='$detail',`email`='$email',`mobile`='$mobile',`price`='$price' WHERE `postId`='$postId'";
  
  
   mysqli_query($con,$query);
  echo "Post Has Been Updated";  

   mysqli_close($con);
?>