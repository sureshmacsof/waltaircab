<?php 
@session_start();



if(isset($_SESSION['UserName']) && isset($_SESSION['Email']) )
			{
				 $UserName = $_SESSION['UserName'];
				 $Email= $_SESSION['Email'];
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['Email'] =$Email;
					
			}
				
		else {  
				 header('location: ../login.php');
				  
			 }
     
  /*
	 include('connect.php');
	  
	   


        $sql = "SELECT  `journalName`, `Title`,  `Email` ,`Status` FROM `ojal_user_journal_details` WHERE  `Email`='$Email' "; 		   
	   
	   
   
    $rs_result = mysqli_query($con, $sql); 
	
	*/


?>


<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Admin Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    <link href="assets/css/custom.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="assets/img/sidebar-2.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                   Admin Dashboard
                </a>
            </div>

            <ul class="nav">
               
				
				<li class="active"><a data-toggle="tab" href="#PostFreeAds"><i class="pe-7s-id"></i>
                        <p>Post Free Ads</p></a></li>
				<li><a data-toggle="tab" href="#ManageAds"><i class="pe-7s-note2"></i>
                        <p>Manage Ads</p></a></li>
				<li><a data-toggle="tab" href="#UnapprovedAds"><i class="pe-7s-trash"></i>
                        <p>Unapproved Ads</p></a></li>
				<li><a data-toggle="tab" href="#MyProfile"> <i class="pe-7s-user"></i>
                        <p>My Profile</p></a></li>
				<li><a data-toggle="tab" href="#EditProfile"><i class="pe-7s-config"></i>
                        <p>Edit Profile</p></a></li>
				
               
				
            </ul>
    	</div>
    </div>

  <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    

                    <ul class="nav navbar-nav navbar-right">
                        
						 <li>
                            <a href="#">
                                <?php echo"$UserName"; ?>
                            </a>
                        </li>
						
						
                        <li>
                            <a href="logout">
                                Log out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


  <div class="content">
   <div class="container-fluid">
			
	 <div class="tab-content">
   
        <div id="PostFreeAds" class="tab-pane fade in active">
	  
	            <div class="row">

                    <div class="col-md-12">
                         <div class="card">
                            <div class="header">
                                <h4 class="title">Post Free Ads</h4>
                            </div>
                            <div class="content">
                               <form class="reg-page">
						
									<div class="row">
										<div class="col-sm-6">
											<label>First Name <span class="color-red">*</span></label>
											<input type="text" class="form-control margin-bottom-20">
										</div>
										<div class="col-sm-6">
											<label>Last Name <span class="color-red">*</span></label>
											<input type="text" class="form-control margin-bottom-20">
										</div>
									</div>
									
									
									<div class="row">
										<div class="col-sm-6">
											<label>Email Address <span class="color-red">*</span></label>
											<input type="text" class="form-control margin-bottom-20">
										</div>
										<div class="col-sm-6">
											<label>Mobile <span class="color-red">*</span></label>
											<input type="text" class="form-control margin-bottom-20">
										</div>
									</div>
									
									<div class="row">
										<div class="col-sm-6">
											<label>Password <span class="color-red">*</span></label>
											<input type="password" class="form-control margin-bottom-20">
										</div>
										<div class="col-sm-6">
											<label>Confirm Password <span class="color-red">*</span></label>
											<input type="password" class="form-control margin-bottom-20">
										</div>
									</div>
									
									<div class="row">
										<div class="col-sm-6">
											<label>Country <span class="color-red">*</span></label>
											
											
									<select id="countries" class="form-control margin-bottom-20"  name="country">
										<option value="">Select Country</option>
																			<option value="ABW">Aruba</option>
																			<option value="AFG">Afghanistan</option>
																			<option value="AGO">Angola</option>
																			<option value="AIA">Anguilla</option>
																			<option value="ALB">Albania</option>
																			<option value="AND">Andorra</option>
																			<option value="ANT">Netherlands Antilles</option>
																			<option value="ARE">United Arab Emirates</option>
																			<option value="ARG">Argentina</option>
																			<option value="ARM">Armenia</option>
																			<option value="ASM">American Samoa</option>
																			<option value="ATA">Antarctica</option>
																			<option value="ATF">French Southern Territories</option>
																			<option value="ATG">Antigua and Barbuda</option>
																			<option  value="Australia">Australia</option>
																			<option value="AUT">Austria</option>
																			<option value="AZE">Azerbaijan</option>
																			<option value="BDI">Burundi</option>
																			<option value="BEL">Belgium</option>
																			<option value="BEN">Benin</option>
																			<option value="BFA">Burkina Faso</option>
																			<option value="BGD">Bangladesh</option>
																			<option value="BGR">Bulgaria</option>
																			<option value="BHR">Bahrain</option>
																			<option value="BHS">Bahamas</option>
																			<option value="BIH">Bosnia</option>
																			<option value="BLR">Belarus</option>
																			<option value="BLZ">Belize</option>
																			<option value="BMU">Bermuda</option>
																			<option value="BOL">Bolivia</option>
																			<option value="BRA">Brazil</option>
																			<option value="BRB">Barbados</option>
																			<option value="BRN">Brunei Darussalam</option>
																			<option value="BTN">Bhutan</option>
																			<option value="BVT">Bouvet Island</option>
																			<option value="BWA">Botswana</option>
																			<option value="CAF">Central African Republic</option>
																			<option value="CAN">Canada</option>
																			<option value="CCK">Cocos Islands</option>
																			<option value="CHE">Switzerland</option>
																			<option value="CHL">Chile</option>
																			<option value="CHN">China</option>
																			<option value="CIV">Cote D&#39;Ivoire</option>
																			<option value="CMR">Cameroon</option>
																			<option value="COG">Congo</option>
																			<option value="COK">Cook Islands</option>
																			<option value="COL">Colombia</option>
																			<option value="COM">Comoros</option>
																			<option value="CPV">Cape Verde</option>
																			<option value="CRI">Costa Rica</option>
																			<option value="CUB">Cuba</option>
																			<option value="CXR">Christmas Island</option>
																			<option value="CYM">Cayman Islands</option>
																			<option value="CYP">Cyprus</option>
																			<option value="CZE">Czech</option>
																			<option value="DEU">Germany</option>
																			<option value="DJI">Djibouti</option>
																			<option value="DMA">Dominica</option>
																			<option value="DNK">Denmark</option>
																			<option value="DOM">Dominican Republic</option>
																			<option value="DZA">Algeria</option>
																			<option value="ECU">Ecuador</option>
																			<option value="EGY">Egypt</option>
																			<option value="ERI">Eritrea</option>
																			<option value="ESH">Western Sahara</option>
																			<option value="ESP">Spain</option>
																			<option value="EST">Estonia</option>
																			<option value="ETH">Ethiopia</option>
																			<option value="FIN">Finland</option>
																			<option value="FJI">Fiji</option>
																			<option value="FLK">Falkland Islands</option>
																			<option value="FRA">France</option>
																			<option value="FRO">Faeroe Islands</option>
																			<option value="FSM">Micronesia</option>
																			<option value="GAB">Gabon</option>
																			<option value="GEO">Georgia</option>
																			<option value="GGY">Guernsey</option>
																			<option value="GHA">Ghana</option>
																			<option value="GIB">Gibraltar</option>
																			<option value="GIN">Guinea</option>
																			<option value="GLP">Guadaloupe</option>
																			<option value="GMB">Gambia</option>
																			<option value="GNB">Guinea-Bissau</option>
																			<option value="GNQ">Equatorial Guinea</option>
																			<option value="GRC">Greece</option>
																			<option value="GRD">Grenada</option>
																			<option value="GRL">Greenland</option>
																			<option value="GTM">Guatemala</option>
																			<option value="GUF">French Guiana</option>
																			<option value="GUM">Guam</option>
																			<option value="GUY">Guyana</option>
																			<option value="HKG">Hong Kong</option>
																			<option value="HMD">Heard and McDonald Islands</option>
																			<option value="HND">Honduras, Republic of </option>
																			<option value="HRV">Hrvatska (Croatia)</option>
																			<option value="HTI">Haiti</option>
																			<option value="HUN">Hungary</option>
																			<option value="IDN">Indonesia</option>
																			<option value="IMN">Isle of Man</option>
																			<option selected="selected" value="INDIA">India</option>
																			<option value="IOT">British Indian Ocean Territory</option>
																			<option value="IRL">Ireland</option>
																			<option value="IRN">Iran</option>
																			<option value="IRQ">Iraq</option>
																			<option value="ISL">Iceland</option>
																			<option value="ISR">Israel</option>
																			<option value="ITA">Italy</option>
																			<option value="JAM">Jamaica</option>
																			<option value="JEY">Jersey</option>
																			<option value="JOR">Jordan</option>
																			<option value="JPN">Japan</option>
																			<option value="KAZ">Kazakhstan</option>
																			<option value="KEN">Kenya</option>
																			<option value="KGZ">Kyrgyz</option>
																			<option value="KHM">Cambodia</option>
																			<option value="KIR">Kiribati</option>
																			<option value="KNA">St. Kitts and Nevis</option>
																			<option value="KOR">Korea</option>
																			<option value="KWT">Kuwait</option>
																			<option value="LAO">Lao People&#39;s</option>
																			<option value="LBN">Lebanon</option>
																			<option value="LBR">Liberia</option>
																			<option value="LBY">Libya</option>
																			<option value="LCA">St. Lucia</option>
																			<option value="LIE">Liechtenstein</option>
																			<option value="LKA">Sri Lanka</option>
																			<option value="LSO">Lesotho</option>
																			<option value="LTU">Lithuania</option>
																			<option value="LUX">Luxembourg</option>
																			<option value="LVA">Latvia</option>
																			<option value="MAC">Macao</option>
																			<option value="MAR">Morocco</option>
																			<option value="MCO">Monaco</option>
																			<option value="MDA">Moldova</option>
																			<option value="MDG">Madagascar</option>
																			<option value="MDV">Maldives</option>
																			<option value="MEX">Mexico</option>
																			<option value="MHL">Marshall Islands</option>
																			<option value="MKD">Macedonia</option>
																			<option value="MLI">Mali</option>
																			<option value="MLT">Malta</option>
																			<option value="MMR">Myanmar</option>
																			<option value="MNG">Mongolia</option>
																			<option value="MNP">Northern Mariana Islands</option>
																			<option value="MOZ">Mozambique</option>
																			<option value="MRT">Mauritania</option>
																			<option value="MSR">Montserrat</option>
																			<option value="MTQ">Martinique</option>
																			<option value="MUS">Mauritius</option>
																			<option value="MWI">Malawi</option>
																			<option value="MYS">Malaysia</option>
																			<option value="MYT">Mayotte</option>
																			<option value="NAM">Namibia</option>
																			<option value="NCL">New Caledonia</option>
																			<option value="NER">Niger</option>
																			<option value="NFK">Norfolk Island</option>
																			<option value="NGA">Nigeria</option>
																			<option value="NIC">Nicaragua</option>
																			<option value="NIU">Niue</option>
																			<option value="NLD">Netherlands</option>
																			<option value="NOR">Norway</option>
																			<option value="NPL">Nepal</option>
																			<option value="NRU">Nauru</option>
																			<option value="NZL">New Zealand</option>
																			<option value="OMN">Oman, Sultanate</option>
																			<option value="PAK">Pakistan</option>
																			<option value="PAN">Panama</option>
																			<option value="PCN">Pitcairn Island</option>
																			<option value="PER">Peru</option>
																			<option value="PHL">Philippines</option>
																			<option value="PLW">Palau</option>
																			<option value="PNG">Papua New Guinea</option>
																			<option value="POL">Poland</option>
																			<option value="PRI">Puerto Rico</option>
																			<option value="PRK">Korea</option>
																			<option value="PRT">Portugal</option>
																			<option value="PRY">Paraguay</option>
																			<option value="PSE">Palestinian Territory</option>
																			<option value="PYF">French Polynesia</option>
																			<option value="QAT">Qatar, State of </option>
																			<option value="REU">Reunion</option>
																			<option value="ROU">Romania</option>
																			<option value="RUS">Russian Federation</option>
																			<option value="RWA">Rwanda</option>
																			<option value="SAU">Saudi Arabia</option>
																			<option value="SDN">Sudan</option>
																			<option value="SEN">Senegal</option>
																			<option value="SGP">Singapore</option>
																			<option value="SGS">South Georgia</option>
																			<option value="SHN">St. Helena</option>
																			<option value="SJM">Svalbard &amp;amp; Jan Mayen Islands</option>
																			<option value="SLB">Solomon Islands</option>
																			<option value="SLE">Sierra Leone</option>
																			<option value="SLV">El Salvador</option>
																			<option value="SMR">San Marino</option>
																			<option value="SOM">Somalia</option>
																			<option value="SPM">St. Pierre and Miquelon</option>
																			<option value="STP">Sao Tome and Principe</option>
																			<option value="SUR">Suriname</option>
																			<option value="SVK">Slovakia</option>
																			<option value="SVN">Slovenia</option>
																			<option value="SWE">Sweden</option>
																			<option value="SWZ">Swaziland</option>
																			<option value="SYC">Seychelles</option>
																			<option value="SYR">Syria</option>
																			<option value="TCA">Turks and Caicos Islands</option>
																			<option value="TCD">Chad</option>
																			<option value="TGO">Togo</option>
																			<option value="THA">Thailand</option>
																			<option value="TJK">Tajikistan</option>
																			<option value="TKL">Tokelau</option>
																			<option value="TKM">Turkmenistan</option>
																			<option value="TLS">Timor-Leste ( Formally East Timor )</option>
																			<option value="TON">Tonga</option>
																			<option value="TTO">Trinidad and Tobago</option>
																			<option value="TUN">Tunisia</option>
																			<option value="TUR">Turkey</option>
																			<option value="TUV">Tuvalu</option>
																			<option value="TWN">Taiwan</option>
																			<option value="TZA">Tanzania</option>
																			<option value="UGA">Uganda</option>
																			<option value="UKR">Ukraine</option>
																			<option value="GBR">United Kingdom</option>
																			<option value="UMI">United States Minor Outlying Islands</option>
																			<option value="URY">Uruguay</option>
																			<option value="USA">United States of America</option>
																			<option value="UZB">Uzbekistan</option>
																			<option value="VAT">Holy See</option>
																			<option value="VCT">St. Vincent and the Grenadines</option>
																			<option value="VEN">Venezuela</option>
																			<option value="VGB">British Virgin Islands</option>
																			<option value="VIR">US Virgin Islands</option>
																			<option value="VNM">Viet Nam</option>
																			<option value="VUT">Vanuatu</option>
																			<option value="WLF">Wallis and Futuna Islands</option>
																			<option value="WSM">Samoa</option>
																			<option value="YEM">Yemen</option>
																			<option value="YUG">Yugoslavia</option>
																			<option value="ZAF">South Africa</option>
																			<option value="ZMB">Zambia</option>
																			<option value="ZWE">Zimbabwe</option>
																		</select>
								
							                    </div>
											<div class="col-sm-6">
												<label>State <span class="color-red">*</span></label>
												
												<div id="India" class="contry" style="display:none"> 
												
												 <select class="form-control margin-bottom-20"  name="State">
														<option value="">Select State</option>
																							<option value="Andhra Pradesh ">Andhra Pradesh </option>
																							<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
																							<option value="Arunachal Pradesh">Arunachal Pradesh</option>
																							<option value="Assam">Assam</option>
																							<option value="Bihar">Bihar</option>
																							<option value="Chandigarh">Chandigarh</option>
																							<option value="Chhattisgarh">Chhattisgarh</option>
																							<option value="Delhi">Delhi</option>
																							<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
																							<option value="Daman and Diu">Daman and Diu</option>
																							<option value="Goa">Goa</option>
																							<option value="Gujarat">Gujarat</option>
																							<option value="Haryana">Haryana</option>
																							<option value="Himachal Pradesh">Himachal Pradesh</option>
																							<option value="Jammu and Kashmir">Jammu and Kashmir</option>
																							<option  value="Jharkhand">Jharkhand</option>
																							<option value="Karnataka">Karnataka</option>
																							<option value="Kerala">Kerala</option>
																							<option value="Lakshadweep">Lakshadweep</option>
																							<option value="Madhya Pradesh">Madhya Pradesh</option>
																							<option value="Maharashtra">Maharashtra</option>
																							<option value="Manipur">Manipur</option>
																							<option value="Meghalaya">Meghalaya</option>
																							<option value="Mizoram">Mizoram</option>
																							<option value="Nagaland">Nagaland</option>
																							<option value="Odisha">Odisha</option>
																							<option value="Pondicherry">Pondicherry</option>
																							<option value="Punjab">Punjab</option>
																							<option value="Rajasthan">Rajasthan</option>
																							<option value="Sikkim">Sikkim</option>
																							<option value="Tamil Nadu">Tamil Nadu</option>
																							<option value="Tripura">Tripura</option>
																							<option value="Uttar Pradesh">Uttar Pradesh</option>
																							<option value="Uttarakhand">Uttarakhand</option>
																							<option value="West Bengal">West Bengal</option>
																							
												</select>
												</div>
												
												<div id="all" class="contry" style="display:none">
												 <input type="text" class="form-control margin-bottom-20">
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-sm-12">
												<label>Address <span class="color-red">*</span></label>
												
												<textarea class="form-control margin-bottom-20"></textarea>
											</div>
											
										</div>

										<hr>

										<div class="row">
											<div class="col-lg-6 checkbox">
												<label>
													<input type="checkbox">
													I read <a href="page_terms.html" class="color-green">Terms and Conditions</a>
												</label>
											</div>
											<div class="col-lg-6 text-right">
												<button class="btn-u" type="submit">Register</button>
											</div>
										</div>
									</form>
                            </div>
                        </div>
                    </div>
                </div>

	    </div>
     
	  
	  
	   <div id="ManageAds" class="tab-pane fade">
                
          <p>ManageAds</p>
       </div>
	   
	   
	   <div id="UnapprovedAds" class="tab-pane fade">
                
         <p>UnapprovedAds</p>
       </div>
	   
	   <div id="MyProfile" class="tab-pane fade">
                
        <p>MyProfile</p>
       </div>
	   
	   <div id="EditProfile" class="tab-pane fade">
            <p>EditProfile</p>    

       </div>
	   
	   
    </div>
	
   </div>



    </div>
  </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'pe-7s-gift',
            	message: "Welcome to  ShineClassified Ads"

            },{
                type: 'info',
                timer: 4000
            });

    	});
	</script>

</html>
