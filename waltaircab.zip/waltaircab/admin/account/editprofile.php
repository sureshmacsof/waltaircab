 <?php include 'connect.php';

			$query = mysqli_query($con,"SELECT `FirstName`, `LastName`, `email`, `password`, `country`, `province`, `city`, `address`,  `mobileno` FROM `member` WHERE	`email`='$Email'");
		 
		if($query)
		 {
		 
		 
			
				if(mysqli_num_rows($query) > 0)
				{
				  $row=mysqli_fetch_assoc($query);
					
					 $FirstName=$row["FirstName"];					
					 $LastName=$row["LastName"];
					 $city=$row["city"];
					 $province=$row["province"];
					 $addresse=$row["address"];
					 $passworde=$row["password"];
					 $mobilenum=$row["mobileno"];
					 $country=$row["country"];
					 $email=$row["email"];
					 
				
				}
				
				
				else
				{   
					 $FirstName='';					
					 $LastName='';
					 $city='';
					 $province='';
					 $addresse='';
					 $passworde='';
					 $mobilenum='';
					 $country='To Select Country';
				
					 
				}
		 }	


?>		 
		 