<?php
@session_start(); // Starting Session
$error=''; // Variable To Store Error Message



if (isset($_POST['submit'])) 
{
	
	
	
if (empty($_POST['mobile']) || empty($_POST['password'])) 
{
$error = "Email or Password is invalid";

echo"$error";
}


else
{ 
// Define $username and $password
$mobile=$_POST['mobile'];
$password=$_POST['password'];


 include 'connect.php';
   
// To protect MySQL injection for Security purpose
$mobile = stripslashes($mobile);
$password = stripslashes($password);


$pass=$password;



$query = mysqli_query($con,"SELECT `id`, `name`, `mobile`, `password` FROM `wc_admin` WHERE  password='$pass'  AND mobile='$mobile'");
 
if($query)
 {
    
	 
		if(mysqli_num_rows($query) >= 1)
		 {
			 
			$row=mysqli_fetch_assoc($query);
			
			$_SESSION['UserName'] =$row["name"];
			$_SESSION['mobile'] =$row["mobile"];
			
			
				
				
				
				 echo "<script>window.location.href='index'</script>";
                 exit;
		 }
		
		else
		 {
		     echo "<script>alert('Enter valid User namme and password  or  Register again')</script> ";
			 
		     echo "<script>window.location.href='../index'</script>";
                     exit; 
		 }


}

else { echo"fail";} 

mysqli_close($con); // Closing Connection
}
}
?>