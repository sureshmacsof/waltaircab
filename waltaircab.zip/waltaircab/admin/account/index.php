<?php 
@session_start();



if(isset($_SESSION['UserName']) && isset($_SESSION['mobile']) )
			{
				 $UserName = $_SESSION['UserName'];
				 $mobile= $_SESSION['mobile'];
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['mobile'] =$mobile;
					
			}
				
		else {  
				 header('location: ../login.php');
				  
			 }
			 
   
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	
	<link rel="icon" type="image/png" href="../images/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title> Waltair Cabs | Admin Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS  
      
	-->
	<link href="assets/css/custom.css" rel="stylesheet"/>
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    
	
	<link href="assets/css/jquery.fileupload.css" rel="stylesheet"/>
    <link href="assets/css/jquery.fileupload-ui.css" rel="stylesheet"/>
     
	 
	 

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
    <style>
	  
			  .controls label {
			display: inline-block;
			width: 90px;
			height: 20px;
			text-align: center;
			vertical-align: top;
			padding-top: 40px;
		}
		.controls input {
			display: block;
			margin: 0 auto -40px;
		}
	  
	</style>
	  
	<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>  
	  
   

    	
	  
	 <script language="JavaScript">
   (function (global) 
   { 

    if(typeof (global) === "undefined") {
        throw new Error("window is undefined");
    }

    var _hash = "!";
    var noBackPlease = function () {
        global.location.href += "#";

        // making sure we have the fruit available for juice (^__^)
        global.setTimeout(function () {
            global.location.href += "!";
        }, 50);
    };

    global.onhashchange = function () {
        if (global.location.hash !== _hash) {
            global.location.hash = _hash;
        }
    };

    global.onload = function () {            
        noBackPlease();

        // disables backspace on page except on input fields and textarea..
        document.body.onkeydown = function (e) {
            var elm = e.target.nodeName.toLowerCase();
            if (e.which === 8 && (elm !== 'input' && elm  !== 'textarea')) {
                e.preventDefault();
            }
            // stopping event bubbling up the DOM tree..
            e.stopPropagation();
        };          
    }

   })(window);
  
  
</script>  




    <script src="assets/js/editpost.js"></script>
	
    <link href="assets/css/style.min.css" rel="stylesheet" /> 
	<link href="assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
	<link href="assets/plugins/parsley/src/parsley.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/pace/pace.min.js"></script>
	<!-- ================== END BASE JS ================== -->  
	 
    <script type="text/javascript" src="../js/validation.js"></script> 
	<script type="text/javascript" src="../js/alertify.min.js"></script> 
	<link rel="stylesheet" href="../js/alertify.core2.css">
	<link rel="stylesheet" href="../js/alertify.default.css">
  
</head>
<body>

<div class="wrapper">
    <div class="sidebar" style='background-color:#303840;width:250px;'  data-image="assets/img/sidebar-2.jpg">

   
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                   Admin Dashboard
                </a>
            </div>

            <ul class="nav">
              
				<li class="active"><a data-toggle="tab" href="#PostFreeAds"><i class="pe-7s-upload"></i>
                        <p>Trip Sheet / Bill</p></a></li>
				<li><a data-toggle="tab" href="#ManageAds"><i class="pe-7s-print"></i>
                        <p>Show Trips</p></a></li>
				<li><a data-toggle="tab" href="#UnapprovedAds"><i class="pe-7s-close"></i>
                        <p>Unapproved Ads</p></a></li>
				<li><a data-toggle="tab" href="#MyProfile"> <i class="pe-7s-user"></i>
                        <p>My Profile</p></a></li>
				
               <!-- <li> <a href="#" data-toggle="modal" data-target="#myModal"><i class="pe-7s-user"></i>
                        <p>My Profile</p></a></li>		-->		
						
				<li><a data-toggle="tab" href="#EditProfile"><i class="pe-7s-config"></i>
                        <p>Edit Profile</p></a></li>
				
               
				
            </ul>
    	</div>
    </div>

<div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    

                    <ul class="nav navbar-nav navbar-right">
                        
						<li>
                            <a href="#">
                               <i class="pe-7s-user" style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> <?php echo"$UserName"; ?>
							   
                            </a>
                        </li>
						
						
                        <li>
                            <a href="logout">
							<i class="pe-7s-back" style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


<div class="content">
 <div class="container-fluid">
 <div class="tab-content">
   
 <div id="PostFreeAds" class="tab-pane fade in active">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
                <div class="panel-heading-btn">
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                              
                 </div>
                 <h2 class="panel-title" style="font-size: 20px;">Fill The Trip Sheet Info</h2> 
            </div>		
            <div class="panel-body">
			
			
                <div id="Basic_Post_Info" class="tab-pane in active">
				
				    <form class="reg-page" name="tripDetails"  action="tripDetails" method="post" role="form" enctype="multipart/form-data"  style="background: #fff;margin-bottom: 5px; padding-top:30px;" onsubmit="return confirm('Please Check The Details, After Submition You Can not Modify It?');">
						<!-- general details -->
						
						<div style="border: 1px solid #f5d5d5;padding-left: 5px;padding-right: 5px;margin-bottom: 5px;">
						
						<h4 style="padding-bottom: 10px;">General Details</h4>
                        <div class="row" style="margin-bottom: 30px;">
							 <div class="col-sm-3">
								<label>Trip Sheet No <span class="color-red">*</span></label>
								
								<input  name='sheetNo'  placeholder='Enter  Trip Sheet No' type='number' style='text-align:center;' class="form-control margin-bottom-20">
								
								
							 </div>
							 
							 <div class="col-sm-3">
								<label>Trip Date <span class="color-red">*</span></label>
								
								<input  name='tripDate'  placeholder='Enter  Trip Date' type='date' style='text-align:center;' class="form-control margin-bottom-20">
								
							 </div>
							 
							 <div class="col-sm-3">
								<label>Opening Time <span class="color-red">*</span></label>
								
								<input  name='opening_time'  placeholder='Enter Opening Time' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
							 </div>
							 
							 <div class="col-sm-3">
								<label>Opening  Km's<span class="color-red">*</span></label>
											
								<input  name='opening_kms'  placeholder='Enter  Opening  Kms' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
								
							 </div>
						</div>
						
						</div>
						<!-- general details  close-->
						
						
						<!-- Customer details -->
						<div style="border: 1px solid #f5d5d5;padding-left: 5px;padding-right: 5px;margin-bottom: 5px;">
						<h4 style="padding-bottom: 20px;">Customer Details</h4>
						
						
						<div class="row" style="margin-bottom: 30px;">
							 <div class="col-sm-3">
								<label>Customer Name <span class="color-red">*</span></label>
								
								<input  name='Customer_Name'  placeholder='Enter  Customer Name' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
								
							 </div>
							 
							 <div class="col-sm-3">
								<label>Customer Address <span class="color-red">*</span></label>
								
								<input  name='Customer_Address'  placeholder='Enter  Customer Address' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
							 </div>
							 
							 <div class="col-sm-3">
								<label>Customer Cell No <span class="color-red">*</span></label>
								
								<input  name='Customer_Cell_No'  placeholder='Customer Cell No' type='mobile' style='text-align:center;' class="form-control margin-bottom-20">
								
							 </div>
							 
							 <div class="col-sm-3">
								<label>Reporting Place <span class="color-red">*</span></label>
											
								<input  name='Report_place'  placeholder='Reporting Place' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
								
							 </div>
						</div>
						
						
						<div class="row" style="margin-bottom: 30px;">
							 <div class="col-sm-3">
								<label>Customer Aadhar No <span class="color-red">*</span></label>
								
								<input  name='aadhar_no'  placeholder='Customer Aadhar No' type='number' style='text-align:center;' class="form-control margin-bottom-20">
								
								
							 </div>
							 
							
						</div>
						</div>
						
						
						  <!-- Customer details close -->
						  
						  <!-- Driver details -->
				<div style="border: 1px solid #f5d5d5;padding-left: 5px;padding-right: 5px;margin-bottom: 5px;">
						<h4 style="padding-bottom: 20px;">Driver Details</h4>  
						  
						<div class="row" style="margin-bottom: 30px;">
						
						
							 <div class="col-sm-3">
								<label>Driver Name <span class="color-red">*</span></label>
								
								<input  name='driverName'  placeholder='Driver Name' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
							 </div>
							 
							 <div class="col-sm-3">
								<label>Vehicle No. <span class="color-red">*</span></label>
											
								<input  name='vehicleNo'  placeholder='Enter  Vehicle No' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
								
							 </div>
							 
							 <div class="col-sm-3">
								<label>Advance Amt. <span class="color-red">*</span></label>
											
								<input  name='advance'  placeholder='Enter  Advance Amt' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
								
							 </div>
							 
							 
							 <div class="col-sm-3">
								<label>Total Amt. <span class="color-red">*</span></label>
											
								<input  name='total_amt'  placeholder='Enter  Total Amt' type='text' style='text-align:center;' class="form-control margin-bottom-20">
								
								
							 </div>
						
						
							
							 
						</div>  
				</div>  
						
						
						 <!-- Driver details close --> 
						
					

					
                    <hr>

					<div class="row" style="margin-bottom: 0px;">
											
						<div class="col-sm-offset-1 col-sm-6 text-right">
											
							<input type="submit" class="btn btn-primary btn-lg" name="submit" id="submit" value="Submit" class="waves-button-input" onclick='return validatePost()'> 
							
						</div>
					</div>					
						  
				   </form>

                            
                </div>  <!-- Basic_Post_Info close-->
                       
			
						
              </div>  <!-- tabs Content close-->
           
			
            </div>
        </div>      
     
     </div>
  </div> <!-- post close -->
  
  
  
  
  
  
  
  <!-- ManageAds strt -->
  
   <div id="ManageAds" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
                <div class="panel-heading-btn">
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                              
                 </div>
                 <h2 class="panel-title" style="font-size: 20px;">Manage Ads</h2>
            </div>


			
          
			</div>
		</div>
     </div>
   
   </div><!-- ManageAds Close -->
   
   
   <!-- UnapprovedAds strt -->
  
  <div id="UnapprovedAds" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
                <div class="panel-heading-btn">
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                              
                 </div>
                 <h2 class="panel-title" style="font-size: 20px;">Unapproved Ads</h2>
            </div>		
            <div class="panel-body">
			 	
			</div>
		</div>
     </div>
    </div>
   </div><!-- UnapprovedAds Close -->
   
    <!-- MyProfile strt -->
  
   <div id="MyProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
                <div class="panel-heading-btn">
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                              
                 </div>
                 <h2 class="panel-title" style="font-size: 20px;">My Profile</h2>
            </div>		
            <div class="panel-body" style="padding-top:10px;">
			  fgdfgdgdf
			</div>
		</div>
     </div>
    </div>
   </div><!-- MyProfile Close -->
   
   <!-- EditProfile Start -->
   <div id="EditProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
                <div class="panel-heading-btn">
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                              
                 </div>
                 <h2 class="panel-title" style="font-size: 20px;">Edit Profile</h2>
            </div>		
            <div class="panel-body">
		
			</div>
		</div>
     </div>
    </div>
   </div><!-- EditProfile Close -->
  
  
  
 </div><!-- All Tabs Close -->
	
   </div>
  </div>
 </div>
</div>

<div class="modal fade" id="myModal" role="dialog">
 <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
           <div class="row">
			  <div class="col-md-5  toppad  pull-left">
				   
                <h3>Edit Post Details</h3>
			
			  </div>
		   </div>
        </div>
    <div class="modal-body">
		
     
	<div id="PostShow" align="center">
	</div>
       
    </div>
      
   </div>
  </div>
 </div>



</body>

    <!--   Core JS Files   -->
   
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	
    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

   
    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	

	
	
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<!--[if lt IE 9]>
		<script src="assets/crossbrowserjs/html5shiv.js"></script>
		<script src="assets/crossbrowserjs/respond.min.js"></script>
		<script src="assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	
	
	<!-- 
	<script src="assets/plugins/jquery-cookie/jquery.cookie.js"></script>
	<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>	
	
	-->
	
	
	<!-- ================== END BASE JS ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="assets/plugins/parsley/dist/parsley.js"></script>
	<script src="assets/plugins/bootstrap-wizard/js/bwizard.js"></script>
	<script src="assets/js/form-wizards-validation.demo.min.js"></script>
	<script src="assets/js/apps.min.js"></script>
	<!-- ================== END PAGE LEVEL JS ================== -->
	
	<script>
		$(document).ready(function() {
			App.init();
			FormWizardValidation.init();
		});
	</script>

</html>
