$(document).ready(function(){  
$("#submitpost").click(function(){
var title = $("#titlee").val();
var price = $("#pricee").val();
var category = $("#categorye").val();
var subcategory = $("#subcategorye").val();
var detail = $("#detaile").val();
var state = $("#statee").val();
var city = $("#citye").val();
var mobile = $("#mobilee").val();
var email = $("#emaile").val();
var postIde = $("#postIde").val();
//var categoryNamee = $("#categoryNamee").val();
//var subcatNamee = $("#subcatNamee").val();


  alert(price +state +email+postIde);
  //alert(mid);

// Returns successful data submission message when the entered information is stored in database.
var dataString = 'title1='+title + '&price1='+price  + '&category1='+category  + '&subcategory1='+subcategory + '&detail1='+detail + '&state1='+state + '&city1='+city + '&mobile1='+mobile + '&email1='+email + '&postId1='+postIde ;


if(title=='' || price=='' || category=='' ||  subcategory=='' || detail==''|| state=='' || city=='' || mobile=='' || email=='' )
{
	alert("Please Fill All Fields");
	
	
}
else
{
	
	$.ajax({
			type: "POST",
			url: "../account/editPostbasic.php",
			data: dataString,
			cache: false,
			success: function(result){
								alert(result);
								
									}
	});
	
} 
return false;
});
});