<?php

if(!empty($_POST["category"])) {
	
	
	 include 'connect.php';
    $query ="SELECT    `subcategoryname` , `subcategoryid` FROM `subcategory` WHERE  categoryid= '" . $_POST["category"] . "'";
     
	 
	 
      $result = mysqli_query($con,$query);
	   
	   if($result)
	   {
		   
		 while($row=mysqli_fetch_assoc($result)) 
		 {
			$resultset[] = $row;
		 }		
		  if(!empty($resultset))
			$result =  $resultset;


	   }

	
	
?>
	<option value="">Please Select Sub-Category</option>
<?php
	foreach($result as $subcategory) {
?>
	<option value="<?php echo $subcategory["subcategoryid"]; ?>"><?php echo $subcategory["subcategoryname"]; ?></option>
<?php
	}
}
?>