<?php $servername_access = "localhost";
$username_access = "root";
$password_access ="";
$dbname ="wcabs";


/*$servername_access = "macsoforg.ipagemysql.com";
$username_access = "wcabs";
$password_access ="wcabs";
$dbname ="wcabs"; */ 

 $con=mysqli_connect($servername_access, $username_access, $password_access, $dbname);
 
 ?>