<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="Transfers - Private Transport and Car Hire HTML Template" />
	<meta name="description" content="Transfers - Private Transport and Car Hire HTML Template">
	<meta name="author" content="themeenergy.com">
	
	<title>Waltair Cabs | Tariff</title>
	
	<link rel="stylesheet" href="css/styler.css" />
	<link rel="stylesheet" href="css/theme-pink.css" id="template-color" />
	<link rel="stylesheet" href="css/style.css" />
	<link rel="stylesheet" href="css/animate.css" />
	<link rel="stylesheet" href="css/icons.css" />
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Raleway:400,500,600,700|Montserrat:400,700">
	<link rel="shortcut icon" href="images/favicon.png">
	<script src="js/fontawesome.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  
  <body>
	<!-- Preloader -->
	<div class="preloader">
		<div id="followingBallsG">
			<div id="followingBallsG_1" class="followingBallsG"></div>
			<div id="followingBallsG_2" class="followingBallsG"></div>
			<div id="followingBallsG_3" class="followingBallsG"></div>
			<div id="followingBallsG_4" class="followingBallsG"></div>
		</div>
	</div>
	<!-- //Preloader -->
	
   	<!-- Header -->
		<header class="header" role="banner">
			<div class="wrap">
				<!-- Logo -->
				<div class="logo">
					<a href="index" title="Transfers"><img src="images/transfers.jpg" alt="Transfers" /></a>
				</div>
				<!-- //Logo -->
				
				<!-- Main Nav -->
				<nav role="navigation" class="main-nav">
					<ul>
						<li ><a href="index" title="">Home</a></li>
						<li><a href="about" title="">About Us</a></li>
						<li class="active"><a href="tariff" title="">Waltair Cabs Tariff</a></li>
						<li><a href="destinations" title="Destinations">Destinations</a>
							
						</li>
						<li><a href="contact" title="Contact">Contact</a></li>
						<li><a href="app" title="Contact">Get App</a></li>
					</ul>
				</nav>
				<!-- //Main Nav -->
			</div>
		</header>
		<!-- //Header -->
	
	
	<div class="container-flud">	
		
		<div class="row">
		
		   <div>
					<h2>WALTAIR CABS TARIFF</h2>
					
		   </div>
		   <div class="col-md-6">
		      <table class="data responsive">
							<tr>
								
								<th>HOURS</th>
								<th>KILOMETERS</th>
								<th>TARIFF</th>
							</tr>
							
							<tr>
								
								<td>5</td>
								<td>55</td>
								<td>750</td>
							</tr>	
							
							<tr>
								
								<td>6</td>
								<td>65</td>
								<td>900</td>
							</tr>
							<tr>
								
								<td>7</td>
								<td>75</td>
								<td>1050</td>
							</tr>
							
							<tr>
								
								<td>8</td>
								<td>85</td>
								<td>1200</td>
							</tr>
							
							<tr>
								
								<td>9</td>
								<td>95</td>
								<td>1350</td>
							</tr>
							
							<tr>
								
								<td>10</td>
								<td>105</td>
								<td>1500</td>
							</tr>
						</table>
		   </div>
		   <div class="col-md-6">
		   
		      <table class="data responsive">
							<tr>
								
								<th>HOURS</th>
								<th>TARIFF</th>
								
							</tr>
							
							<tr>
								
								<td>Simhachalam (1 hour waiting only)</td>
								<td>750</td>
								
							</tr>	
							
							<tr>
								
								<td>Annavaram up and down(1 hour waiting only)</td>
								<td>3300</td>
								
							</tr>
							<tr>
								
								<td>Arasavalli and Srikurman (up and down)</td>
								<td>3200</td>
								
							</tr>
							
							<tr>
								
								<td>Araku (up and down)(mini)</td>
								<td>3500</td>
								
							</tr>
							
							
							
						</table>
		   </div>
		</div>
	</div>
		
		
		<div class="wrap">
		
			<div class="row">
				<!--- Content -->
				<div class="full-width content">
					<h2>WALTAIR CABS TARIFF</h2>
					
				</div>
				<!--- //Content -->
				
				<div class="col-md-6">
				
				
						<table class="data responsive">
							<tr>
								
								<th>HOURS</th>
								<th>KILOMETERS</th>
								<th>TARIFF</th>
							</tr>
							
							<tr>
								
								<td>5</td>
								<td>55</td>
								<td>750</td>
							</tr>	
							
							<tr>
								
								<td>6</td>
								<td>65</td>
								<td>900</td>
							</tr>
							<tr>
								
								<td>7</td>
								<td>75</td>
								<td>1050</td>
							</tr>
							
							<tr>
								
								<td>8</td>
								<td>85</td>
								<td>1200</td>
							</tr>
							
							<tr>
								
								<td>9</td>
								<td>95</td>
								<td>1350</td>
							</tr>
							
							<tr>
								
								<td>10</td>
								<td>105</td>
								<td>1500</td>
							</tr>
						</table>
				</div>
				
				
				<div class="col-md-6">
				
				  
				<!-- table 2-->
				<!--- Content -->
				<div class="full-width content">
					<h2>SIGHT SEEING AND TEMPLE PACKAGES</h2>
					
				</div>
				<!--- //Content -->
			
					
						<table class="data responsive">
							<tr>
								
								<th>HOURS</th>
								<th>TARIFF</th>
								
							</tr>
							
							<tr>
								
								<td>Simhachalam (1 hour waiting only)</td>
								<td>750</td>
								
							</tr>	
							
							<tr>
								
								<td>Annavaram up and down(1 hour waiting only)</td>
								<td>3300</td>
								
							</tr>
							<tr>
								
								<td>Arasavalli and Srikurman (up and down)</td>
								<td>3200</td>
								
							</tr>
							
							<tr>
								
								<td>Araku (up and down)(mini)</td>
								<td>3500</td>
								
							</tr>
							
							
							
						</table>
						
						<!--<div class="actions">
							<a href="search-results" class="btn medium back">Go back</a>
							<a href="booking-step2" class="btn medium color right">Continue</a>
						</div> -->
						<h4><br>
						<div class="note" >
						
							<h4>NOTE :</h4>

                            <h4>  * For Mini & Sedan only</h4>

                            <h4>  * Half an hour or more will be calculated as one hour</h4>

                             <h4> * Extra hour : 150/-</h4>

                             <h4> * Extra Kilometer : 10/-</h4>

                             <h4> Terms & Conditions apply</h4>
						</div>
					
				
				<!-- table 2 end -->
				
				
				
				
			     </div>
		    </div>
				
		</div>
					
			
				
				
		
		
		
		<!---<div class="wrap">
			<div class="row">
				
				<div class="full-width content">
					<h2>Baggage and extras</h2>
					<p>Please select the total number of pieces of baggage and extras for your transfers. If you arrive with more luggage than specified at booking, we cannot guarantee to transport them. In case we are able to transport them, we will charge you an additional fee.</p>
				</div>
				
				
				<div class="three-fourth">
					<form>
						<table class="data responsive">
							<tr>
								<th>Baggage type</th>
								<th>Price</th>
								<th>Departure</th>
								<th>Return</th>
							</tr>
							<tr>
								<td>Hand baggage up to 5kg <i>and max dimensions 40 x 22 x 55 cm</i></td>
								<td>Free</td>
								<td>Free</td>
								<td>Free</td>
							</tr>
							<tr>
								<td>Pieces of baggage up to 15kg <i>and max dimensions 53 x 31 x 75 cm</i></td>
								<td>10,00 USD</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
							</tr>
							<tr>
								<td>Pieces of baggage up to 30kg <i>and max dimensions 60 x 35 x 85 cm</i></td>
								<td>15,00 USD</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
							</tr>
							<tr>
								<td>Bicycle, surfing of golf equipment up to 10 kg <i>and max dimensions 152 x 75 x 25 cm</i></td>
								<td>20,00 USD</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
							</tr>
							
							<tr>
								<td>Infant seat <i>for babies weighing up to 9 kg</i></td>
								<td>10,00 USD</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
							</tr>
							
							<tr>
								<td>Baby seat <i>for babies weighing from 9 to 18 kg</i></td>
								<td>10,00 USD</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
							</tr>
							
							<tr>
								<td>Child seat <i>for children weighing from 15 to 36 kg</i></td>
								<td>10,00 USD</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
								<td>
									<select>
										<option selected>0</option>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select>
								</td>
							</tr>
						</table>
						
						<div class="actions">
							<a href="search-results" class="btn medium back">Go back</a>
							<a href="booking-step2" class="btn medium color right">Continue</a>
						</div>
					</form>
				</div>
				
				
				<aside class="one-fourth sidebar right">
					
					<div class="widget">
						<h4>Booking summary</h4>
						<div class="summary">
							<div>
								<h5>DEPARTURE</h5>
								<dl>
									<dt>Date</dt>
									<dd>28.08.2014 10:00</dd>
									<dt>From</dt>
									<dd>London bus station</dd>
									<dt>To</dt>
									<dd>London airport</dd>
									<dt>Vehicle</dt>
									<dd>Private shuttle</dd>
								</dl>
							</div>

							<div>
								<h5>RETURN</h5>
								<dl>
									<dt>Date</dt>
									<dd>02.09.2014 17:00</dd>
									<dt>From</dt>
									<dd>London airport</dd>
									<dt>To</dt>
									<dd>London bus station</dd>
									<dt>Vehicle</dt>
									<dd>Private shuttle</dd>
								</dl>
							</div>
							
							<dl class="total">
								<dt>Total</dt>
								<dd>800,00 usd</dd>
							</dl>
						</div>
					</div>
					
				</aside>
				
			</div>
		</div>-->
		
		
		
	
	<!-- //Main -->
	
	
	<!-- Footer -->
	<footer class="footer blue" role="contentinfo">
		<div class="wrap">
			<div class="row">
				<!-- Column -->
				<article class="one-half">
					<h6>About us</h6>
					<p>Waltair cabs can guarantee the best convenience to all Customers. Waltair Cabs will do our very best for your comfortable and pleasant ride. You can get a special care by taxi drivers before, during, and after their ride. Whether go, so give us a try!Today Waltair Cabs offers its truly world-class services in entire Visakhapatnam.</p>
				</article>
				<!-- //Column -->
				
				<!-- Column -->
				<article class="one-fourth">
					<h6>Need help?</h6>
					<p>Contact us via phone or email:</p>
					<p class="contact-data"><span class="icon icon-themeenergy_call"></span> 0891 65 888 65</p>
					<p class="contact-data" style="margin-left: -30px; "><i style="color: #cc2262;" class="fa fa-mobile fa-2x"  aria-hidden="true" ></i> <span style="margin-top:-10px;">+91 79955 94444</span></p>
					<p class="contact-data"><span class="icon icon-themeenergy_mail-2"></span> <a href="mailto:help@transfers.com">info@waltaircabs.com</a></p>
				</article>
				<!-- //Column -->
				
				<!-- Column -->
				<article class="one-fourth">
					<h6>Follow us</h6>
					<ul class="social">
						<li><a href="https://www.facebook.com/waltair.cabs" title="facebook" target="_blank"><i class="fa fa-fw fa-facebook"></i></a></li>
						<li><a href="http://twitter.com/"  title="twitter" target="_blank"><i class="fa fa-fw fa-twitter"></i></a></li>
						<li><a href="https://plus.google.com/" title="gplus" target="_blank"><i class="fa fa-fw fa-google-plus"></i></a></li>
						<li><a href="https://www.linkedin.com/" title="linkedin" target="_blank"><i class="fa fa-fw fa-linkedin"></i></a></li>
						
					</ul>
				</article>
				<!-- //Column -->
			</div>
			
			<div class="copy">
				<p>Copyright 2016 | All rights reserved. <a href="http://macsof.in/" target="_blank"> Macsof Technologies.</a> </p>
				
				<nav role="navigation" class="foot-nav">
					<ul>
						<li><a href="index" title="Home">Home</a></li>
						<li><a href="about" title="About us">About us</a></li>
						<li><a href="contact" title="Contact us">Contact us</a></li>
						<li><a href="#" title="Terms of use">Terms of use</a></li>
						<li><a href="faq" title="Help">Help</a></li>
						
					</ul>
				</nav>
			</div>
		</div>
	</footer>
	
	
    <!-- jQuery -->
    <script src="ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<script src="js/jquery.uniform.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/scripts.js"></script>
	
	
	<script src="js/styler.js"></script>
  </body>

</html>